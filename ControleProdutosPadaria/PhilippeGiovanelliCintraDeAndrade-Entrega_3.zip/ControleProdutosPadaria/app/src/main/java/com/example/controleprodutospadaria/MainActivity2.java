package com.example.controleprodutospadaria;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {

    ArrayList<Produto> produtos = new ArrayList<>();
    private ListView listViewProdutos;
    private ArrayList<Produto> listaProdutos;
    private ProdutoAdapter produtoAdapter;
    ActivityResultLauncher<Intent> launcherNovoProduto = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {

                        Intent intent = result.getData();

                        Bundle bundle = intent.getExtras();

                        if (bundle != null) {
                            String produto = bundle.getString(MainActivity.PRODUTO);
                            String localProd = bundle.getString(MainActivity.LOCALPROD);
                            String categoriaProd = bundle.getString(MainActivity.CATEGORIAPROD);
                            int validadeProd = bundle.getInt(String.valueOf(MainActivity.VALIDADEPROD));

                            Produto produto1 = new Produto(produto, localProd, categoriaProd, validadeProd);

                            produtos.add(produto1);
                            produtoAdapter.notifyDataSetChanged();

                        }
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        listViewProdutos = findViewById(R.id.listViewProdutos);

        listViewProdutos.setOnItemClickListener((parent, view, position, id) -> {
            Produto produto = (Produto) listViewProdutos.getItemAtPosition(position);
            Toast.makeText(MainActivity2.this, produto.toString() + " foi clicado", Toast.LENGTH_SHORT).show();
        });

        popularLista();
    }

    public void sobre(View view) {
        MainActivity3.nova(this);
    }

    public void novoProduto(View view) {

        MainActivity.novoProduto(this, launcherNovoProduto);
    }

    private void popularLista() {

        String[] nomeProduto = getResources().getStringArray(R.array.nomeProduto);
        String[] localProduto = getResources().getStringArray(R.array.localProduto);
        String[] tipoProduto = getResources().getStringArray(R.array.tipoProduto);
        int[] validade = getResources().getIntArray(R.array.validade);


        for (int cont = 0; cont < nomeProduto.length; cont++) {
            produtos.add(new Produto(nomeProduto[cont], localProduto[cont], tipoProduto[cont], validade[cont]));
        }

        produtoAdapter = new ProdutoAdapter(this, produtos);

        listViewProdutos.setAdapter(produtoAdapter);

    }
}
