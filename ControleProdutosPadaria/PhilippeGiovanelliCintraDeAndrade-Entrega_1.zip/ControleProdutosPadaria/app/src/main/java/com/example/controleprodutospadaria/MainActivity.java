package com.example.controleprodutospadaria;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText editTextProduto;
    private CheckBox cbMesa, cbVitGelada, cbVitQuente;
    private RadioGroup radioGroup;
    private Spinner spinner;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextProduto = findViewById(R.id.editTextProduto);
        radioGroup = findViewById(R.id.radioGroup);
        cbMesa = findViewById(R.id.checkBoxMesa);
        cbVitGelada = findViewById(R.id.checkBoxVitGelada);
        cbVitQuente = findViewById(R.id.checkBoxVitQuente);
        spinner = findViewById(R.id.spinner);

        popularSpinner();

    }
    private void popularSpinner(){
        ArrayList<String> lista = new ArrayList<>();

        lista.add(getString(R.string.tresDias));
        lista.add(getString(R.string.seteDias));
        lista.add(getString(R.string.dozeDias));
        lista.add(getString(R.string.vinteEUmDias));

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1, lista);

        spinner.setAdapter(adapter);
    }
    public void limparFormulario(View view){
        editTextProduto.setText(null);
        cbMesa.setChecked(false);
        cbVitGelada.setChecked(false);
        cbVitQuente.setChecked(false);
        radioGroup.clearCheck();
        spinner.setSelection(0);


        editTextProduto.requestFocus();
        Toast.makeText(this, R.string.campos_limpos, Toast.LENGTH_SHORT).show();
    }

    public void adicionarProduto(View view){

        String mensagem = "";
        String mensagemRadio= "";
        String mensagemSpinner = (String) spinner.getSelectedItem();
        String produto= editTextProduto.getText().toString();

        if (produto == null || produto.trim().isEmpty()){
            Toast.makeText(this, R.string.erro_nome, Toast.LENGTH_SHORT).show();
            editTextProduto.requestFocus();
            return;
        }


        if (cbMesa.isChecked()){
            mensagem += getString(R.string.mesa) + "\n";
        }
        if (cbVitGelada.isChecked()){
            mensagem += getString(R.string.vitrineGelada) + "\n";
        }
        if (cbVitQuente.isChecked()){
            mensagem += getString(R.string.vitrineQuente) + "\n";
        }
        if (mensagem.equals("")){
            mensagem = getString(R.string.selecioneCampo);
            Toast.makeText(this, mensagem, Toast.LENGTH_SHORT).show();
            return;

        }else{
            mensagem = getString(R.string.localProduto) + "\n" + mensagem;

        }
        int opcao = radioGroup.getCheckedRadioButtonId();

        if (opcao == R.id.radioButtonDoces){
            mensagemRadio = getString(R.string.doces) + getString(R.string.foi_selecionado);
        }else
        if (opcao == R.id.radioButtonSalgados){
            mensagemRadio = getString(R.string.salgados) + getString(R.string.foi_selecionado);
        }else
        if (opcao == R.id.radioButtonBolos){
            mensagemRadio = getString(R.string.bolos) + getString(R.string.foi_selecionado);
        }else
            if (opcao == R.id.radioButtonPaes){
                mensagemRadio = getString(R.string.paes) + getString(R.string.foi_selecionado);
        }else{
                mensagemRadio = getString(R.string.selecione_uma_categoria_de_produto);
                Toast.makeText(this, mensagemRadio, Toast.LENGTH_SHORT).show();
                radioGroup.requestFocus();
                return;
        }




        Toast.makeText(this, produto.trim() + getString(R.string.foi_adicionado)+"\n\n"+mensagem+"\n\n"+mensagemRadio+"\n\n"+getString(R.string.validade)+"\n"+mensagemSpinner , Toast.LENGTH_LONG).show();
        editTextProduto.setText(null);
    }
}