package com.example.controleprodutospadaria;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {

    private ListView listViewProdutos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        listViewProdutos = findViewById(R.id.listViewProdutos);

        listViewProdutos.setOnItemClickListener((parent, view, position, id) -> {
            Produto produto = (Produto) listViewProdutos.getItemAtPosition(position);
            Toast.makeText(MainActivity2.this, produto.toString() + " foi clicado", Toast.LENGTH_SHORT).show();
        });

        popularLista();
    }

    private void popularLista(){

        String[] nomeProduto = getResources().getStringArray(R.array.nomeProduto);
        String[] localProduto = getResources().getStringArray(R.array.localProduto);
        String[] tipoProduto = getResources().getStringArray(R.array.tipoProduto);
        int[] validade = getResources().getIntArray(R.array.validade);

        ArrayList<Produto> produtos = new ArrayList<>();
        for(int cont=0;cont<nomeProduto.length;cont++){
            produtos.add(new Produto(nomeProduto[cont],localProduto[cont],tipoProduto[cont],validade[cont]));
        }
        try {
            ProdutoAdapter produtoAdapter = new ProdutoAdapter(this, produtos);

            listViewProdutos.setAdapter(produtoAdapter);
        } catch (Exception e) {
            e.printStackTrace();
        }


/*
        ArrayAdapter<String> adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,produtos);
        listViewProdutos.setAdapter(adapter);
*/
    }
}