package com.example.controleprodutospadaria;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.ActionMode;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity2 extends AppCompatActivity {

    ArrayList<Produto> produtos = new ArrayList<>();
    private ListView listViewProdutos;
//    private ArrayList<Produto> listaProdutos;
    private ProdutoAdapter produtoAdapter;
    private ActionMode actionMode;
    private View viewSelecionada;
    private int posicaoSelecionada= -1;

    private ActionMode.Callback actionCallback = new ActionMode.Callback() {
        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            MenuInflater inflater = mode.getMenuInflater();
            inflater.inflate(R.menu.principal_item_selecionado,menu);
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {

            int idMenuItem = item.getItemId();

            if (idMenuItem == R.id.menuItemEditar){
                editarProduto();
                mode.finish();
                return true;

            } else if (idMenuItem == R.id.menuItemExcluir) {
                excluirPessoa();
                mode.finish();
                return  true;

            }else {
                return false;
            }


        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {

            if (viewSelecionada!=null){
                viewSelecionada.setBackgroundColor(Color.TRANSPARENT);
            }
            actionMode = null;
            viewSelecionada= null;

            listViewProdutos.setEnabled(true);
        }
    };
    ActivityResultLauncher<Intent> launcherNovoProduto = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {

                        Intent intent = result.getData();

                        Bundle bundle = intent.getExtras();

                        if (bundle != null) {
                            String produto = bundle.getString(MainActivity.PRODUTO);
                            String localProd = bundle.getString(MainActivity.LOCALPROD);
                            String categoriaProd = bundle.getString(MainActivity.CATEGORIAPROD);
                            int validadeProd = bundle.getInt(String.valueOf(MainActivity.VALIDADEPROD));

                            Produto produto1 = new Produto(produto, localProd, categoriaProd, validadeProd);

                            produtos.add(produto1);
                            Collections.sort(produtos, Produto.comparator);
                            produtoAdapter.notifyDataSetChanged();

                        }
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        listViewProdutos = findViewById(R.id.listViewProdutos);

        listViewProdutos.setOnItemClickListener((parent, view, position, id) -> {
            Produto produto = (Produto) listViewProdutos.getItemAtPosition(position);
            Toast.makeText(MainActivity2.this, produto.toString() + " foi clicado", Toast.LENGTH_SHORT).show();
        });

        listViewProdutos.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        listViewProdutos.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                if (actionMode != null){
                    return false;
                }

                posicaoSelecionada=position;
                view.setBackgroundColor(Color.LTGRAY);
                viewSelecionada = view;
                listViewProdutos.setEnabled(false);

                actionMode = startSupportActionMode(actionCallback);
                return false;
            }
        });


        popularLista();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.principal_opcoes, menu);
        return true;
    }

/* ------------------PRIMEIRO EXEMPLO PARA UTILIZAR MENUS------
    @Override
        public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int botao= item.getItemId();

        if(botao == R.id.menuNovoProduto){
            novoProduto(null);
            return true;


        } else
            if (botao == R.id.menuSobre) {
                sobre(null);
                return true;

        }else {
                return super.onOptionsItemSelected(item);}
    }
*/

    public void sobre(MenuItem item) {
        MainActivity3.nova(this);
    }

    public void novoProduto(MenuItem item) {

        MainActivity.novoProduto(this, launcherNovoProduto);
    }

    private void popularLista() {



        produtoAdapter = new ProdutoAdapter(this, produtos);

        listViewProdutos.setAdapter(produtoAdapter);

    }

    ActivityResultLauncher<Intent> launcherEditarProduto = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {

                        Intent intent = result.getData();

                        Bundle bundle = intent.getExtras();

                        if (bundle != null) {
                            String produto = bundle.getString(MainActivity.PRODUTO);
                            String localProd = bundle.getString(MainActivity.LOCALPROD);
                            String categoriaProd = bundle.getString(MainActivity.CATEGORIAPROD);
                            int validadeProd = bundle.getInt(String.valueOf(MainActivity.VALIDADEPROD));

                            Produto produto1 = produtos.get(posicaoSelecionada);
                            produto1.setNomeProduto(produto);
                            produto1.setLocalProduto(localProd);
                            produto1.setTipoProduto(categoriaProd);
                            produto1.setDataValidade(validadeProd);
                            Collections.sort(produtos, Produto.comparator);

                            posicaoSelecionada= -1;

                            produtoAdapter.notifyDataSetChanged();

                        }
                    }
                }
            });

    private void editarProduto(){
        Produto produto = produtos.get(posicaoSelecionada);
        MainActivity.editarProduto(this,launcherEditarProduto,produto);
    }

    private void excluirPessoa(){
        produtos.remove(posicaoSelecionada);
        produtoAdapter.notifyDataSetChanged();
    }
}
